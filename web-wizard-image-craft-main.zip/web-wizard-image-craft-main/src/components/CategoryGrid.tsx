import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";

const categories = [
  {
    id: 1,
    name: "Racing Jackets",
    description: "Premium leather & fabric racing jackets",
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=300&fit=crop",
    itemCount: 24,
    featured: true
  },
  {
    id: 2,
    name: "Team Tees",
    description: "Official team colors & designs",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=300&fit=crop",
    itemCount: 45,
    featured: false
  },
  {
    id: 3,
    name: "Racing Caps",
    description: "Aerodynamic caps for street & track",
    image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=400&h=300&fit=crop",
    itemCount: 18,
    featured: false
  },
  {
    id: 4,
    name: "Speed Accessories",
    description: "Watches, gloves & racing gear",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=300&fit=crop",
    itemCount: 32,
    featured: false
  },
  {
    id: 5,
    name: "Track Shoes",
    description: "Performance footwear inspired by F1",
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=300&fit=crop",
    itemCount: 28,
    featured: false
  },
  {
    id: 6,
    name: "Limited Edition",
    description: "Exclusive championship collections",
    image: "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=400&h=300&fit=crop",
    itemCount: 12,
    featured: true
  }
];

const CategoryGrid = () => {
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-primary to-racing-yellow bg-clip-text text-transparent">
              Racing Categories
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover our premium collection of F1-inspired streetwear, designed for champions on and off the track.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {categories.map((category) => (
            <Card
              key={category.id}
              className="group relative overflow-hidden border-none bg-gradient-to-br from-card to-muted/50 hover:shadow-xl transition-all duration-500 transform hover:scale-105"
            >
              <Link to={`/category/${category.id}`}>
                <div className="relative overflow-hidden rounded-t-lg">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-48 object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  {category.featured && (
                    <div className="absolute top-3 right-3 bg-gradient-to-r from-primary to-racing-yellow text-white text-xs font-bold px-3 py-1 rounded-full">
                      FEATURED
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-muted-foreground mb-4">{category.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {category.itemCount} items
                    </span>
                    <ArrowRight className="h-4 w-4 text-primary transform transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
            </Card>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center">
          <Button variant="racing" size="lg" asChild>
            <Link to="/categories">
              View All Categories
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;