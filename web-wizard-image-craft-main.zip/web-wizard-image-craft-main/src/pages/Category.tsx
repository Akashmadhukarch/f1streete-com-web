import { useState } from "react";
import { useParams } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Filter, Grid, List, Star, ShoppingCart } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Monaco GP Racing Jacket",
    price: 299,
    originalPrice: 399,
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop",
    rating: 4.8,
    reviews: 124,
    colors: ["Black", "Red", "White"],
    sizes: ["S", "M", "L", "XL"],
    onSale: true
  },
  {
    id: 2,
    name: "Silverstone Track Jacket",
    price: 249,
    image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop",
    rating: 4.6,
    reviews: 89,
    colors: ["Navy", "Silver", "Black"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    onSale: false
  },
  {
    id: 3,
    name: "Spa-Francorchamps Limited Edition",
    price: 449,
    image: "https://images.unsplash.com/photo-1564557287817-3785e38ec1f5?w=400&h=400&fit=crop",
    rating: 5.0,
    reviews: 67,
    colors: ["Black", "Gold"],
    sizes: ["M", "L", "XL"],
    onSale: false
  },
  {
    id: 4,
    name: "Monza Speed Bomber",
    price: 199,
    originalPrice: 279,
    image: "https://images.unsplash.com/photo-1520975954732-35dd22299614?w=400&h=400&fit=crop",
    rating: 4.7,
    reviews: 156,
    colors: ["Red", "Black", "White"],
    sizes: ["S", "M", "L", "XL"],
    onSale: true
  },
  {
    id: 5,
    name: "Suzuka Rain Jacket",
    price: 329,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&h=400&fit=crop",
    rating: 4.5,
    reviews: 98,
    colors: ["Navy", "Gray"],
    sizes: ["M", "L", "XL", "XXL"],
    onSale: false
  },
  {
    id: 6,
    name: "Brands Hatch Classic",
    price: 179,
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=400&fit=crop",
    rating: 4.4,
    reviews: 112,
    colors: ["Black", "White", "Green"],
    sizes: ["S", "M", "L"],
    onSale: false
  }
];

const Category = () => {
  const { id } = useParams();
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  
  const categoryName = "Racing Jackets";

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 via-racing-yellow/10 to-primary/10 border-b">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-2">
            <span className="bg-gradient-to-r from-primary to-racing-yellow bg-clip-text text-transparent">
              {categoryName}
            </span>
          </h1>
          <p className="text-muted-foreground">Premium F1-inspired racing jackets for the streets</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-64 space-y-6">
            <Card className="p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Filters
              </h3>
              
              {/* Price Range */}
              <div className="space-y-3 mb-6">
                <h4 className="font-medium">Price Range</h4>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2">
                    <input type="checkbox" className="rounded" />
                    <span className="text-sm">Under $200</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input type="checkbox" className="rounded" />
                    <span className="text-sm">$200 - $300</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input type="checkbox" className="rounded" />
                    <span className="text-sm">$300 - $400</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input type="checkbox" className="rounded" />
                    <span className="text-sm">Over $400</span>
                  </label>
                </div>
              </div>

              {/* Colors */}
              <div className="space-y-3 mb-6">
                <h4 className="font-medium">Colors</h4>
                <div className="flex flex-wrap gap-2">
                  {["Black", "Red", "White", "Navy", "Silver", "Gold"].map((color) => (
                    <button
                      key={color}
                      className="w-8 h-8 rounded-full border-2 border-muted transition-colors hover:border-primary"
                      style={{
                        backgroundColor: color.toLowerCase() === "silver" ? "#C0C0C0" : 
                                       color.toLowerCase() === "navy" ? "#001F3F" :
                                       color.toLowerCase() === "gold" ? "#FFD700" :
                                       color.toLowerCase()
                      }}
                      title={color}
                    />
                  ))}
                </div>
              </div>

              {/* Sizes */}
              <div className="space-y-3">
                <h4 className="font-medium">Sizes</h4>
                <div className="grid grid-cols-3 gap-2">
                  {["S", "M", "L", "XL", "XXL"].map((size) => (
                    <button
                      key={size}
                      className="border border-muted rounded p-2 text-sm hover:border-primary hover:bg-primary/5 transition-colors"
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            </Card>
          </div>

          {/* Products */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <span className="text-muted-foreground">{products.length} products</span>
                <div className="flex items-center gap-2">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="icon"
                    onClick={() => setViewMode("grid")}
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="icon"
                    onClick={() => setViewMode("list")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <select className="border border-input rounded-md px-3 py-2 text-sm bg-background">
                <option>Sort by: Featured</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Rating</option>
                <option>Newest</option>
              </select>
            </div>

            {/* Products Grid */}
            <div className={`grid gap-6 ${
              viewMode === "grid" 
                ? "grid-cols-1 md:grid-cols-2 xl:grid-cols-3" 
                : "grid-cols-1"
            }`}>
              {products.map((product) => (
                <Card
                  key={product.id}
                  className="group overflow-hidden border-none bg-gradient-to-br from-card to-muted/30 hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    {product.onSale && (
                      <Badge className="absolute top-3 left-3 bg-primary text-white">
                        SALE
                      </Badge>
                    )}
                    <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button size="icon" variant="secondary" className="rounded-full">
                        <ShoppingCart className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                      {product.name}
                    </h3>
                    
                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-racing-yellow text-racing-yellow" />
                        <span className="text-sm ml-1">{product.rating}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">({product.reviews})</span>
                    </div>
                    
                    <div className="flex items-center gap-2 mb-4">
                      <span className="text-2xl font-bold text-primary">${product.price}</span>
                      {product.originalPrice && (
                        <span className="text-sm text-muted-foreground line-through">
                          ${product.originalPrice}
                        </span>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap gap-1 mb-4">
                      {product.colors.slice(0, 3).map((color) => (
                        <div
                          key={color}
                          className="w-4 h-4 rounded-full border border-muted"
                          style={{
                            backgroundColor: color.toLowerCase() === "silver" ? "#C0C0C0" : 
                                           color.toLowerCase() === "navy" ? "#001F3F" :
                                           color.toLowerCase() === "gold" ? "#FFD700" :
                                           color.toLowerCase()
                          }}
                          title={color}
                        />
                      ))}
                      {product.colors.length > 3 && (
                        <span className="text-xs text-muted-foreground">+{product.colors.length - 3}</span>
                      )}
                    </div>
                    
                    <Button className="w-full" variant="racing">
                      Add to Cart
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Category;