import Hero from "@/components/Hero";
import CategoryGrid from "@/components/CategoryGrid";

const Home = () => {
  return (
    <div className="min-h-screen">
      <Hero />
      <CategoryGrid />
    </div>
  );
};

export default Home;